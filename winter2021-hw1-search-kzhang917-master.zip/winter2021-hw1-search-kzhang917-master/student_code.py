from expand import expand

def a_star_search (dis_map, time_map, start, end):
	# Create open and closed sets, as well as table and path:
	open = []
	closed = []
	data = {}
	# Add start node to open set and table:
	open.append(start)
	data[start] = {'Distance from Start': 0,
				   'Heuristic Distance': dis_map[start][end],
				   'Sum': dis_map[start][end],
				   'Previous Vertex': None}
	curr = start
	while open:
		if curr == end:
			path = []
			path_node = curr
			while path_node is not None:
				path = [path_node] + path
				last_node = data[path_node]['Previous Vertex']
				path_node = last_node
			return path


		neighbors = expand(curr, time_map)

		for n in neighbors:
			if n not in closed:
				if n in data:
					new_dist = data[curr]['Distance from Start'] + time_map[curr][n]
					if new_dist < data[n]['Distance from Start']:
						data[n]['Distance from Start'] = new_dist
						heur_dist = dis_map[n][end]
						sum = new_dist + heur_dist
						data[n]['Sum'] = sum
						data[n]['Previous Vertex'] = curr
				else:
					new_dist = data[curr]['Distance from Start'] + time_map[curr][n]
					heur_dist = dis_map[n][end]
					sum = new_dist + heur_dist
					data[n] = {'Distance from Start': new_dist,
							   'Heuristic Distance': heur_dist,
							   'Sum': sum,
							   'Previous Vertex': curr}
					open.append(n)
		open.remove(curr)
		closed.append(curr)
		min_sum = None
		next_node = None
		for node in dis_map:
			if node in open:
				sum = data[node]['Sum']
				if not min_sum:
					min_sum = sum
					next_node = node
				elif sum < min_sum:
					min_sum = sum
					next_node = node
		curr = next_node

	return None




def depth_first_search(time_map, start, end):
	path = []
	fringe = [start]
	fringe_paths = [[start]]
	while fringe:
		curr = fringe.pop()
		path = fringe_paths.pop()
		if curr == end:
			break
		neighbors = expand(curr, time_map)
		if neighbors:
			for n in neighbors:
				fringe.append(n)
				fringe_paths.append(path + [n])
	return path




def breadth_first_search(time_map, start, end):
	path = []
	fringe = [start]
	fringe_paths = [[start]]
	expanded = [start]
	while fringe:
		curr = fringe.pop(0)
		path = fringe_paths.pop(0)
		if curr == end:
			break
		neighbors = expand(curr, time_map)
		if neighbors:
			for n in neighbors:
				if n not in expanded:
					fringe.append(n)
					fringe_paths.append(path + [n])
					expanded.append(n)
	return path