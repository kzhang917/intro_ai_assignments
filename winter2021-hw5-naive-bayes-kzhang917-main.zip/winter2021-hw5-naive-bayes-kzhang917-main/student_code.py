import math
import re

class Bayes_Classifier:

    def __init__(self):
        self.class_pr = {}
        self.word_pr = {}
        self.num_lines = 0
        self.class_counts = {}
        self.word_counts = {}
        self.stop_words = ['a', 'an', 'and', 'are', 'as', 'at', 'be', 'by', 'for', 'from', 'has', 'he', 'in',
                           'is', 'it', 'its', 'of', 'on', 'that', 'the', 'to', 'was', 'were', 'will', 'with']



    def train(self, lines):
        word_regex = r'\b\w+\b'
        # Count classes and words for all lines:
        for line in lines:
            fields = line.split('|')
            rating = fields[0]
            if rating in self.word_counts:
                self.class_counts[rating] += 1
            else:
                self.class_counts[rating] = 1
                self.word_counts[rating] = {}
            text = fields[2]
            words = re.findall(word_regex, text)
            for word in words:
                if word not in self.stop_words:
                    if word in self.word_counts[rating]:
                        self.word_counts[rating][word] += 1
                    else:
                        self.word_counts[rating][word] = 1
            self.num_lines += 1
        # Generate probabilities from counts:
        for rating in self.class_counts:
            self.class_pr[rating] = self.class_counts[rating] / self.num_lines
            self.word_pr[rating] = {}
            for word in self.word_counts[rating]:
                self.word_pr[rating][word] = self.word_counts[rating][word] / self.class_counts[rating]





    def classify(self, lines):
        word_regex = r'\b\w+\b'
        result = []
        for line in lines:
            fields = line.split('|')
            text = fields[2]
            words = re.findall(word_regex, text)
            pred_class = None
            pred_prob = -math.inf
            for rating in self.class_pr:
                log_likelihood = math.log(self.class_pr[rating])
                # Calculate the average likelihood to be used when the word doesn't exist in training data:
                avg_likelihood = 1 / len(self.word_pr[rating])
                for word in words:
                    if word not in self.stop_words:
                        if word in self.word_pr[rating]:
                            curr = math.log(self.word_pr[rating][word])
                            log_likelihood += curr
                        else:
                            curr = math.log(avg_likelihood)
                            log_likelihood += curr
                if log_likelihood > pred_prob:
                    pred_prob = log_likelihood
                    pred_class = rating
            result.append(pred_class)
        return result
