
def ask(var, value, evidence, bn):
	copy1 = evidence.copy()
	alpha = joint_prob(bn.variable_names, copy1, bn)
	evidence[var] = value
	copy2 = evidence.copy()
	jp = joint_prob(bn.variable_names, copy2, bn)
	print(jp)
	print(alpha)
	return jp / alpha

def joint_prob(vars, evidence, bn):
	if not vars:
		return 1
	first = vars[0]
	if first in evidence:
		value = evidence[first]
		return bn.get_var(first).probability(value, evidence) * joint_prob(vars[1:], evidence, bn)
	else:
		evidence_false = evidence.copy()
		evidence_true = evidence.copy()
		evidence_false[first] = False
		evidence_true[first] = True
		return (bn.get_var(first).probability(True, evidence) * joint_prob(vars[1:], evidence_true, bn)
				+ bn.get_var(first).probability(False, evidence) * joint_prob(vars[1:], evidence_false, bn))


